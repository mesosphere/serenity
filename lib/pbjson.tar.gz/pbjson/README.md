pbjson
======

A fast C++ serialization and de-serialization of Google's protobuf Messages into/from JSON format, which built on [rapidjson](https://code.google.com/p/rapidjson/), inspired from [json2pb](https://github.com/shramov/json2pb).

## Embedding pbjson

Just copy all files in 'src' folder into your project. 




